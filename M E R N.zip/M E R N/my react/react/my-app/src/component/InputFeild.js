import React from 'react'

export default function InputFeild() {
    function add() {
        var a = document.getElementById('para')
        a.innerHTML += "<input/> <br/>"
    }
    return (


            <>
        <fieldset>

            <form>
                <label>
                    Name:
                    <input type="text" name="name" />
                </label>
                <input type="submit" value="Submit" />
                <input type="button" value="+" onClick={add} />
                {/* <input type="text" id='' /> */}
                <p id='para'></p>

            </form>


        </fieldset >
        </>
    )
}

