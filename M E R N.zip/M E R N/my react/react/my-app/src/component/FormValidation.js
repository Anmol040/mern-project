import React, { Component } from 'react'

export default class FormValidation extends Component {





    constructor() {
        super();
        this.state = {
            name: "",
            password: "",
            nameError: "",
            passwordError: ""


        }
    }
    valid() {
        // if (!this.setState.name.includes("@") && this.state.password.length < 5) {

        //     this.setState({ nameError: "invalid Name", passwordError: "password length should be more than 5" })
        // }
        if (!this.state.name.toString().includes("@")) {
            console.log(this.state.name)

            this.setState({ nameError: "invalid Name" })
        }
        // else if (this.state.password.length < 5) {

        //     this.setState({ passwordError: "password length should be more than 5" })
        // }
        else{

            alert(" form has been submit");
        }}
        submit() {
            if (this.valid()) {
                // console.log("submit")
            }
        }
        render() {
            return (
                <div className='App'>
                    <h1>Form Validation</h1>
                    <input type="text" onChange={(event) => { this.setState({ name: event.target.value }) }} />
                    <p>{this.state.nameError}</p>
                    <input type="password" onChange={(event) => { this.setState({ password: event.target.value }) }} />
                    <p>{this.state.passwordError}</p>
                    <button onClick={() => this.valid()}>submit</button>


                </div>
            )
        }

    }

