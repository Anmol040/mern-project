// import React, { useState } from 'react';
// import axios from 'axios';

//  function App() {
//   const [file, setFile] = useState(null);
//   const [output, setOutput] = useState('');

//   const handleSubmit = async (e) => {
//     e.preventDefault();
//     const formData = new FormData();
//     formData.append('file', file);

//     try {
//       const res = await axios.post('/convert', formData, {
//         headers: {
//           'Content-Type': 'multipart/form-data',
//         },
//       });
//       setOutput(res.data);
//     } catch (err) {
//       console.error(err);
//     }
//   };

//   const handleFileChange = (e) => {
//     setFile(e.target.files[0]);
//   };

//   return (
//     <div>
//       <h1>PPT to PDF Converter</h1>
//       <form onSubmit={handleSubmit}>
//         <input type="file" onChange={handleFileChange} />
//         <button type="submit">Convert</button>
//       </form>
//       {output && (
//         <div>
//           <h2>Output PDF:</h2>
//           <iframe src={output} width="600" height="400"></iframe>
//         </div>
//       )}
//     </div>
//   );
// }

// export default App;
import React, { useState } from "react";
import PptxGenJS from "pptxgenjs";

const PptToPdfConverter = () => {
  const [pptFile, setPptFile] = useState(null);
  const [pdfFile, setPdfFile] = useState(null);

  const handleFileUpload = (e) => {
    setPptFile(e.target.files[0]);
  };

  const convertToPdf = () => {
    const pptx = new PptxGenJS();
    pptx.load(pptFile);
    pptx.writeFile(`${pptFile.name}.pdf`, { base64: true }, (data) => {
      setPdfFile(data);
    });
  };

  return (
    <div>
      <h2>Convert PPT to PDF</h2>
      <input type="file" onChange={handleFileUpload} />
      <button onClick={convertToPdf}>Convert</button>
      {pdfFile && (
        <a href={`data:application/pdf;base64,${pdfFile}`} download>
          Download PDF
        </a>
      )}
    </div>
  );
};

export default PptToPdfConverter;
