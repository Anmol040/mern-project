
import React, { Component} from 'react'

export default class ClassComponent extends Component {
  render() {
    return (
      <div>
        <h1> this is anmol {this.props.text}</h1>
        
      </div>
    )
  }
}

