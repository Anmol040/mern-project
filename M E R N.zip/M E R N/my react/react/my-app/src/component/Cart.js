import React from 'react'
import "./Cart.css"

export default function Cart() {
    const data=[
        {
            name: "CAT",
            discription: "this is cat",
           image:"https://images.pexels.com/photos/45201/kitty-cat-kitten-pet-45201.jpeg?cs=srgb&dl=pexels-pixabay-45201.jpg&fm=jpg"

        },
        {
           name: "dog",
           discription: "this is dog",
           image:"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSuIgPTOonYx-CVQGqzvBhgCJ2ToolA7c9hVA&usqp=CAU"

        }
    ]
  return (
    <div className='box'>{
        data.map((user)=>
        <>
        <img src={user.image} alt="no image"/>
        <h1> {user.name} </h1>
        <p> {user.discription} </p>
        </>

   )}
      
    </div>
  )
}
