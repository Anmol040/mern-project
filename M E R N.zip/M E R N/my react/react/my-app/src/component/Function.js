import React from 'react'

export default function Function(prop) {
    const red=()=>{
        alert ("DAMAGE")
        
    }
    
  return (
    <div>
      <h1 onClick={red}>{prop.text}</h1>
    </div>
  )
}
