import React from 'react'

export default function EventHandling() {
  return (
    <div>
      <h1> Events</h1>
      <button>CLICK ME</button>
    </div>
  )
}
