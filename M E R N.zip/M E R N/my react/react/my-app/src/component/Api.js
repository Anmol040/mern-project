import React, { useEffect,useState} from 'react'
import axios from "axios"


export default function Api() {
    const [first,setfirst]= useState()
   document.write("111",first);
    useEffect(()=> {
        axios.get("https://dummyjson.com/product/categories")
        .then((response) => setfirst(response.data))
    },[])
    
  return (
    <>
   {
    first?.map((data)=> {
       document.write("ok",data);
    })
   }
    </>
  )
}
