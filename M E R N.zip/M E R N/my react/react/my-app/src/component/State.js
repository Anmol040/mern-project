import React, { Component } from 'react'

export default class State extends Component {
  flag = 1
    constructor()
    {
        super()
        this.state={
            name:"anmol",
            email:"anmol@gmail.com",
            count:1
        }
    }
updatestate()
{
  if (this.flag === 1){
    this.setState({
      name: "Bhardwaj",
      email: "test01@gmail.com",
      count:this.state.count+1
    })
    this.flag = 0
  } else{
    this.setState({
      name:"anmol",
      email:"anmol@gmail.com",
      count:this.state.count+1
    })                                                                                                                                                 
    this.flag = 1
  }
  
}

  render() {
    return (
      <div>
        <h1>HELLO {this.state.name} </h1>
        <h1> EMAIL {this.state.email} </h1>
        <h1> count {this.state.count} </h1>
        <button onClick={()=> {this.updatestate()}} > UPDATE ME </button>
      </div>
    )
  }
}
