import React, { Component } from 'react'

export default class Toggel extends Component {
    constructor() {
        super();
        this.state={show:true};
    }
    render() {
        return (
            <div>

                {
                    this.state.show?  <h1> HIDE AND SHOW </h1>:null
                }
            
                <button onClick={() => { this.setState({ show: !this.state.show }) }} >click me</button>

            </div>
        )
    }
}


