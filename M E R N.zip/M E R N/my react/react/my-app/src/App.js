
import './App.css';
import Navbar from './component/Navbar';
// import Form from './component/Form';
import { useState } from 'react';
import ClassComponent from './component/ClassComponent';
import Function from './component/Function';
import TextEditor from './TextEditor';
import Toggel from './component/Toggel'
import State from './component/State'
import Cart from './component/Cart';
import Api from './component/Api';
import InputFeild from './component/InputFeild';
import FormValidation from'./component/FormValidation';
import Pdf from'./component/Pdf';




function App() {
 
  return (
    <>
      <Navbar />
  
      <TextEditor/>
      <Toggel/>
      <State/>
      <ClassComponent text={"123456"} />
      <Function text={"mr bhardwaj"} />
      <Cart/>
      {/* <Api/> */}
      {/* <InputFeild/>
      <FormValidation/> */}
    {/* <Pdf/> */}




    </>
  );
}

export default App;

