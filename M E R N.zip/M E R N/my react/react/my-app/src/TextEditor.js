import React, { useState } from 'react'

export default function TextEditor() {
    const [text, setText] = useState()
    function uppercase() {
      setText(text.toUpperCase())
  
    }
    function lowercase() {
      setText(text.toLowerCase())
  
    }
    function clear() {
      setText(" ")
  
    }
    function camelCase() {
      var a = text[0]
      var b = ""
      var i = 1
      while (i < text.length) {
        if (text[i - 2] === '.') {
          var g = text[i]
          b += g.toUpperCase()
        } else {
          b += text[i]
        }
        i += 1
      }
      var c = a.toUpperCase() + b
      setText(c)
    }
  
    const upp = ((e) =>
      setText(e.target.value))
  return (
    <div>
      <fieldset >
        <div className="container">
          <h1>TEXT CONVERTOR</h1>
          <textarea class="form-control" placeholder=" ਇੱਥੇ ਟਾਈਪ ਕਰੋ " id="floatingTextarea" value={text} onChange={upp} rows={10}></textarea>
          <button type="button" class="btn btn-primary my-3 mx-2" onClick={uppercase}>uppercase</button>
          <button type="button" class="btn btn-primary my-3 mx-3" onClick={lowercase}>lowercase</button>
          <button type="button" class="btn btn-primary my-3 mx-3" onClick={clear}>clear</button>
          <button type="button" class="btn btn-primary my-3 mx-3" onClick={camelCase}>camelcase</button>

        </div>
        <div className="container">
          <h3>TEXT SUMMERY</h3>
          <p>No. of words{ } No. of Character{ }</p>
        </div>
      </fieldset>
    </div>
  )
}
