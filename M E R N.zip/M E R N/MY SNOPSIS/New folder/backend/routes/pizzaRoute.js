const express = require('express')
const router = express.Router();
const pizzaModel = require('../models/pizzaModels')

//GET ALL PIZZA || @GET REQUEST
router.get('/getALLPizzas', async (req,res)=>{
    try {
        const pizzas = await pizzaModel.find({})
        res.send(pizzas)
    } catch (error) {
        res.json({message:error})
    }
})

module.exports = router;