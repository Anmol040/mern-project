const mongoose = require("mongoose");


const connectDB = async () => {
const db =  "mongodb+srv://anmolpizza:anmolanmol@cluster0.b8xzdwi.mongodb.net/anmolpizza?retryWrites=true&w=majority"
mongoose.connect(db).then(()=>{ 
    console.log('conencted successfuly');
}).catch((err)=>{ 
    console.log("Error received= " + err)
})
}

module.exports = connectDB;