const mongoose = require("mongoose");

const Schema = mongoose.Schema;

const bookSchema = new Schema({ 
  name: {
  type:String,
  require:true
},
varients:
  [
    small= { type: String },
    medium={ type: String },
    large= { type: String },
    _id=false
]
,
prices: [
  {
    small: { type: Number },
    medium: { type: Number },
    large: { type: Number },
    _id:false
  }
],   
category:{
  type:String,
  required:true
},
image:{
  type:String,
  required:true
},
description:{
  type:String
}
},{timestamps:true});

module.exports = mongoose.model("pizzas", bookSchema);


