import axios from 'axios'

export const getALLPizzas = () => {
 return async (dispatch) => {
  dispatch({ type: 'GET_PIZZAS_SUCESS' })
  try {
    const res = await axios.get("/api/pizzas/getALLPizzas");
    // console.log("res",res)
    dispatch({
      type: 'GET_PIZZAS_SUCESS',
      payload: res.data
    });
  } catch (err) {
    dispatch({
      type: "GET_PIZZAS_FAIL",
      payload: err
    });

  }
}
}

