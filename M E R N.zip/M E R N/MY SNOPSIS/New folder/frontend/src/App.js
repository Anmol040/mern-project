import { BrowserRouter, Route } from "react-router-dom";
import "./App.css";
import About from "./Components/About";
import Contact from "./Components/Contact";
import Policy from "./Components/Policy";
import HomeScreen from "./Screens/HomeScreen";
import CartScreen from "./Screens/CartScreen";
import React from "react";
import Register from "./Screens/Register";
import Login from "./Screens/login";
import Addnew from "./Screens/Addnew"
import ShowData from "./Screens/ShowData";


function App() {
  return (
    <>
      <BrowserRouter>
        {/* <TopBar/> */}
     
      
        <Route path="/login" component={Login} />
        <Route path="/register" component={Register} />
        <Route path="/" component={HomeScreen} exact/>
        <Route path="/About" component={About} />
        <Route path="/cart" component={CartScreen} />
        <Route path="/contact" component={Contact} />
        <Route path="/Policy" component={Policy} />
        <Route path='/addnew-item' component={Addnew } />
        <Route path='/show-item' component={ShowData } />
     

      </BrowserRouter>
    </>
  );
}

export default App;
