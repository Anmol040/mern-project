import React, { useEffect, useState } from 'react';
// import { Button, message } from "antd";
import axios from 'axios'
import AdminNav from '../Components/AdminNav';
import { Input, Button, message } from "antd";
// import DeleteIcon from '@material-ui/icons';


export default function ShowData() {
  const [show, setShow] = useState(false);
  const [foodItems, setFoodItems] = useState([]);
  const [bookToUpdate, setBookToUpdate] = useState({
    name: "",
    description: "",
  });

  const loadData = async () => {
    let response = await fetch("http://localhost:8080/books", {
      method: "get",
      headers: {
        'Content-Type': 'application/json'
      }
    });
    response = await response.json();
    setFoodItems(response.books);
  };

  const handleDelete = async (bookId) => {
    try {
      await axios.delete(`http://localhost:8080/books/${bookId}`);
      message.success("Book deleted successfully");
    } catch (error) {
      message.error("Failed to delete book");
    }
  };
  // const getById = async (bookId) => {
  //   try {
  //     const res=await axios.get(`http://localhost:5000/books/${bookId}`);
  //     message.success("Book get successfully");
  //     console.log("data",res)
  //   } catch (error) {
  //     message.error("Failed to delete book");
  //   }
  // };

  const toggleEdit = ()=>{
    if(show === false){
      setShow(true)
    }else{
      setShow(false)
    }

  }

  const handleUpdate = async (bookId) => {
    try {
      await axios.put(`http://localhost:8080/books/${bookId}`, bookToUpdate);
      message.success("Book updated successfully");
      // Clear form fields
      setBookToUpdate({
        name: "",
        description: "",
      });

    } catch (error) {
      message.error("Failed to update book");
    }
  };


  useEffect(() => {
    loadData();
  }, []);

  return (
    <div className=''>
      <AdminNav />
      <h1 className='justify-content-center row m-4'>Avalible-Food-Item</h1>
      <table className='table table-hover '>
        <thead className=' text-success fs-4'>
          <tr>
            <th scope='col' >#</th>
            <th scope='col' >_id</th>
            <th scope='col' >CategoryName</th>
            <th scope='col' >Name</th>
            <th scope='col' >Image</th>
            <th scope='col' >description</th>

          </tr>
        </thead>
        <tbody className='text-dark'>
          {foodItems.map((food, index) => (
            <tr>
              <th scope='row' >{index + 1}</th> 
              <td >{food._id}</td>
              <td>{food.category}</td>
              <td>{food.name}</td>
              <td>{food.image}</td>
              <td>{food.description}</td>
              <Button className='bg-danger m-1 p-2 text-light'
                type="danger"
                onClick={() => handleDelete(food._id)}
              >
                Delete
              </Button>
              <Button className='bg-primary m-0.5 p-2 text-light'
                type="danger"
                onClick={toggleEdit}
              >
                Edit
              </Button>
              <Button className='bg-success m-1 p-2 text-light' type="primary" onClick={() => handleUpdate(food._id)}>
                Confirm-update
              </Button>
              {/* <Button className='bg-success m-1 p-2 text-light' type="primary" onClick={() => getById(food._id)}>
                getbyid
              </Button> */}
            </tr>
          ))}
        </tbody>
      </table>
      {show === true ?
        <div className='container'>
          <Input
            className="form-control"
            style={{ width: "30%" }}
            placeholder="New Name"
            value={bookToUpdate.name}
            onChange={(e) =>
              setBookToUpdate({
                ...bookToUpdate,
                name: e.target.value,
              })
            }
          />
          <Input
            className="form-control"
            style={{ width: "30%" }}
            placeholder="New category"
            value={bookToUpdate.category}
            onChange={(e) =>
              setBookToUpdate({
                ...bookToUpdate,
                category: e.target.value,
              })
            }
          />
          <Input
            className="form-control"
            style={{ width: "30%" }}
            placeholder="New image"
            value={bookToUpdate.image}
            onChange={(e) =>
              setBookToUpdate({
                ...bookToUpdate,
                image: e.target.value,
              })
            }
          />
          <Input
            className="form-control"
            style={{ width: "30%" }}
            placeholder="New Price"
            value={bookToUpdate.price}
            onChange={(e) =>
              setBookToUpdate({
                ...bookToUpdate,
                price: e.target.value,
              })
            }
          />
          <Input.TextArea
            className="form-control"
            style={{ width: "30%" }}
            placeholder="New Description"
            value={bookToUpdate.description}
            onChange={(e) =>
              setBookToUpdate({
                ...bookToUpdate,
                description: e.target.value,
              })
            }
          />
          </div>
        : null}
    </div>
  );
}
