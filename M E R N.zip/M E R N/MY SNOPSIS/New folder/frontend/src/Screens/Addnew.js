import React from "react";
import { Input, message } from "antd";
import { useState } from "react";
import axios from "axios";
import AdminNav from '../Components/AdminNav'

function AddBooks() {
    const [admin, setAdmin] = useState({
       
        name: "",
        image: "",
        category: "",
        description: "",
        small: "",
        medium: "",
        large: ""

    });
    // console.log("var", admin.varients)
    const handleadd = (e) => {
        e.preventDefault(); // Prevtent form submission
        axios.post("http://localhost:8080/books/", {
         
            name: admin.name,
            image: admin.image,
            category: admin.category,
            description: admin.description,
            small: admin.small,
            medium: admin.medium,
            large: admin.large
        });
        // console.log(admin.options[0])
        message.success("Food-item added successfully");
        // Clear form fields
        setAdmin({
         
            name: "",
            image: "",
            category: "",
            small: "",
            description: "",
            medium: "",
            large: ""
        });
    };

    return (
        <div className="">
            <AdminNav />
            <h1 className="text-center mt-4">Admin Panel</h1>
            <div className="container col justify-content-center my-4">
                <h3>Add New Food Items</h3>
               
                <div className="form-group">
                    <label htmlFor="category">category:</label>
                    <select class="form-select" style={{ width: "30%" }}
                        value={admin.category}
                        onChange={(e) => {  
                            setAdmin({
                                ...admin,
                                category: e.target.value
                            });
                        }} aria-label="Default select example">
                        <option selected>veg</option>
                        <option >non-veg</option>
                        
                    </select>
                </div>
                <div className="form-group">
                    <label htmlFor="itemName">Name:</label>
                    <Input
                        id="itemName"
                        className="form-control"
                        style={{ width: "30%" }}
                        value={admin.name}
                        onChange={(e) => {
                            setAdmin({
                                ...admin,
                                name: e.target.value
                            });
                        }}
                    />
                </div>
                <div className="form-group">
                    <label htmlFor="image">Image:</label>
                    <Input
                        id="image"
                        className="form-control"
                        style={{ width: "30%" }}
                        value={admin.image}
                        onChange={(e) => {
                            setAdmin({
                                ...admin,
                                image: e.target.value
                            });
                        }}
                    />
                </div>
                <div className="form-group">
                    <label htmlFor="small">small :</label>
                    <Input
                        id="small"
                        className="form-control"
                        style={{ width: "30%" }}
                        value={admin.small}
                        onChange={(e) => {
                            setAdmin({
                                ...admin,
                                small: e.target.value
                            });
                        }}
                    />
                </div>

                <div className="form-group">
                    <label htmlFor="medium">medium:</label>
                    <Input
                        id="medium"
                        className="form-control"
                        style={{ width: "30%" }}
                        value={admin.medium}
                        onChange={(e) => {
                            setAdmin({
                                ...admin,
                                medium: e.target.value
                            });

                        }}
                    />
                </div>
                
                <div className="form-group">
                    <label htmlFor="large">large:</label>
                    <Input
                        id="large"
                        className="form-control"
                        style={{ width: "30%" }}
                        value={admin.large}
                        onChange={(e) => {
                            setAdmin({
                                ...admin,
                                large: e.target.value
                            });

                        }}
                    />
                </div>
                <div className="form-group">
                    <label htmlFor="description">Description:</label>
                    <Input.TextArea
                        id="description"
                        className="form-control"
                        style={{ width: "30%" }}
                        value={admin.description}
                        onChange={(e) => {
                            setAdmin({
                                ...admin,
                                description: e.target.value
                            });
                        }}
                    />
                </div>
                <button className="btn btn-primary mt-3" onClick={handleadd}>Add</button>
            </div>
        </div>
    );
}

export default AddBooks;

