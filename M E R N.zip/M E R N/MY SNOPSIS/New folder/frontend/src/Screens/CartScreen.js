import React from 'react'
import { Container, Row, Col } from 'react-bootstrap'
import { useSelector, useDispatch } from 'react-redux'
import { AiOutlineMinusCircle } from 'react-icons/ai';
import { HiPlusCircle} from 'react-icons/hi'
import{FaTrash } from "react-icons/fa";
import { addToCart,deletFromCart } from '../actions/cartAction'
const CartScreen = () => {
  const cartState = useSelector(state => state.cartReducer)
  const cartItems = cartState.cartItems
  const dispatch = useDispatch()
  const subTotal = cartItems.reduce((x,item) => x + item.price,0)
  return (
    <>
      <Container>
        <Row>
          <Col md={6}>
            <h1> My Cart </h1>
            <Row>
              {
                cartItems.map(item => (
                  <>
                    <Col md={7}>
                      <h5>{item.name} [{item.varient}] </h5>
                      <h6> Price: {item.quantity} X {item.price[0]} = {" "}
                        {item.price} </h6>
                      <h6> Quantity:
                        <AiOutlineMinusCircle
                         className='text-danger'
                          style={{ cursor: "pointer" }}
                          onClick={() => { dispatch(addToCart(item,item.quantity - 1, item.varient)) }}
                        /> &nbsp;
                        {item.quantity}&nbsp;
                        <HiPlusCircle
                          className='text-success'
                          style={{ cursor: "pointer" }}
                          onClick={() => { dispatch(addToCart(item, item.quantity + 1, item.varient)) }} />
                      </h6>
                    </Col>
                    <Col md={5}> <img src={item.image} alt={item.name} style={{ width: "200px", height: "100px" }} />
                    <FaTrash  className='text-danger'
                          style={{ cursor: "pointer", marginLeft: "20px" }}
                          onClick={() => {
                             dispatch(deletFromCart(item));
                              }}/>
                     </Col>
                    <hr />
                  </>
                ))}
            </Row>
          </Col>
          <Col md={4}>
            <h1> Payment Info </h1> </Col>
            <h4> Rs :{subTotal} /- </h4>
        </Row>
      </Container>
    </>
  )
}

export default CartScreen
