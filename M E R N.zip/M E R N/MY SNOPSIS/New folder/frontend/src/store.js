import getALLPizzaReducer from "./reducer/pizzaReducer"
import { configureStore } from '@reduxjs/toolkit'
import { combineReducers } from 'redux';
import { cartReducer } from "./reducer/cartReducer";
import { registerUserReducer,loginUserReducer} from "./reducer/userReducer";
const cartItems = localStorage.getItem('cartItems') ? JSON.parse(localStorage.getItem('cartItems')) : [];

const currentUser = localStorage.getItem('currentUser') ? JSON.parse (localStorage.getItem('currentUser')) :null;
const rootReducer = combineReducers({
  getALLPizzaReducer,
  cartReducer,
  registerUserReducer,
  loginUserReducer
});

const initialState = {
  cartReducer: {
    cartItems: cartItems,
  },
  loginUserReducer:{
    currentUser:currentUser
  }
};

const store = configureStore({ reducer: rootReducer, initialState: initialState.cartReducer })

export default store;