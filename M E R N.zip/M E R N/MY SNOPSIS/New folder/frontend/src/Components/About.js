import React from 'react'
import { Container, Row, Col } from 'react-bootstrap'
import NavBar from './Navbar'

const About = () => {
    return (
        <>
        <NavBar/>
            <Container style={{ marginTop: '50px' }} />
            {/* <h4> whoe we are</h4> */}
{/* <p> Lorem, ipsum             dolor sit amet consectetur adipisicing elit. Consequatur possimus et animi quo quibusdam officiis maxime quae ullam voluptates omnis, vel harum quisquam assumenda aperiam similique a tempore at illum asperiores consectetur quas veritatis illo cupiditate. Libero iure amet repellendus quos quo sit vitae fugiat ad minima excepturi corrupti recusandae a perspiciatis dicta doloribus fugit quasi, fuga sed dolor voluptas eligendi exercitationem dolorum vel quis. Quo impedit quae beatae ab facilis, totam ipsa, voluptatibus mollitia explicabo et, ipsum suscipit? Fugit aperiam eligendi quia, saepe sed consequatur quam voluptatibus odio consequuntur blanditiis asperiores est provident esse alias accusamus sint rem perspiciatis veniam maiores corporis qui obcaecati adipisci dignissimos. Sequi cumque veniam consectetur, cupiditate suscipit culpa eaque a voluptatum nostrum dolor animi? Voluptate odio quaerat iure ex reiciendis esse ea quis eius pariatur repellendus, dolorem necessitatibus aliquam consequatur voluptatem blanditiis quidem quas omnis ullam in quos asperiores? Nesciunt fugit numquam beatae eaque incidunt exercitationem laborum earum, eum dolorum soluta sit blanditiis facilis sapiente quod! Suscipit repellendus aspernatur ipsa eum architecto sunt laborum dolorem illo officiis tenetur consectetur est, error atque ad cupiditate cum adipisci enim praesentium quo non nulla nesciunt incidunt. Adipisci officiis modi quasi repellat omnis cum dignissimos assumenda provident hic.</p> */}
            {/* <h4> our Speciality</h4> */}
            {/* <Row>
                <Col md={6}>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Provident veritatis pariatur enim repudiandae quis ipsa perferendis nihil non explicabo. Corrupti eligendi libero debitis voluptate totam suscipit odit aliquid voluptatem aut ipsam dolore consequuntur ipsum consequatur animi doloremque quaerat inventore similique aliquam officiis autem esse tenetur, temporibus odio! Deleniti id eaque magni nobis quo rem, laborum animi beatae velit vel hic. Veniam, aliquam. Eligendi corporis laborum neque nam impedit aperiam placeat blanditiis totam veniam vero distinctio repudiandae explicabo, excepturi laudantium vitae reprehenderit, dolor tempora dicta quis amet recusandae consequuntur modi. Cupiditate tenetur temporibus amet iste ullam sed iusto asperiores illo at.</p>
                </Col>
                <Col md={6}>
                    <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Sit atque esse minima at totam impedit, iusto, voluptatem inventore eveniet cum cumque corporis. Expedita, hic. Accusamus dolorem vero quae asperiores accusantium illo reiciendis libero ab, nostrum molestias excepturi rerum iste aliquam et minima expedita ipsam animi dolore possimus magnam. Id fugit voluptatum perferendis tenetur vero facilis sunt corrupti ea earum non, nihil praesentium veritatis necessitatibus qui unde iusto ipsam eum odio impedit officia provident rem! Qui esse neque, iusto porro illum nemo vitae, ipsam error, facilis nihil debitis! Reiciendis quasi fugiat exercitationem sed dignissimos libero ratione cum, ex vel, illo repudiandae!</p>
                </Col>

            </Row> */}
            <Row>
                {/* <h4> Our Cheif</h4> */}
                {/* <Col md={3}>Welcome to Pizza Shop! We are passionate about crafting delicious, high-quality pizzas that are made with love and the finest ingredients. Here's what sets us apart:</Col>
                <Col md={3}>Quality Ingredients:
At Pizza Shop, we believe that great pizza starts with great ingredients. That's why we source the freshest produce, finest meats, and premium cheeses to create mouthwatering flavor combinations. Each pizza is made to order, ensuring that you get a piping hot, fresh-out-of-the-oven experience every time.</Col>
                <Col md={3}>Handcrafted Pizzas:
Our skilled pizzaiolos take pride in handcrafting each pizza with precision and care. From stretching the dough to layering the toppings, we pay attention to every detail to deliver a pizza that is visually appealing and bursting with flavor.</Col>
                <Col md={3}>Variety of Flavors:
We offer an extensive menu with a wide range of flavors to cater to all tastes. Whether you prefer classic Margherita, meat lovers, vegetarian, or gourmet combinations, we have something for everyone. Don't forget to check out our seasonal specials and chef's recommendations for a unique pizza experience.</Col> */}
 
 
 
 
 <h4> About Us</h4>




<p> Welcome to Pizza Shop ! We are passionate about crafting delicious, high-quality pizzas that are made with love and the finest ingredients. Here's what sets us apart:
</p>
<h4> Quality Ingredients: </h4>
<p> At Pizza Shop , we believe that great pizza starts with great ingredients. That's why we source the freshest produce, finest meats, and premium cheeses to create mouthwatering flavor combinations. Each pizza is made to order, ensuring that you get a piping hot, fresh-out-of-the-oven experience every time.
</p>
<h4> Handcrafted Pizzas: </h4>
<p> Our skilled pizzaiolos take pride in handcrafting each pizza with precision and care. From stretching the dough to layering the toppings, we pay attention to every detail to deliver a pizza that is visually appealing and bursting with flavor.
</p>
<h4> Variety of Flavors:</h4>
<p> We offer an extensive menu with a wide range of flavors to cater to all tastes. Whether you prefer classic Margherita, meat lovers, vegetarian, or gourmet combinations, we have something for everyone. Don't forget to check out our seasonal specials and chef's recommendations for a unique pizza experience.
</p>
<h4> Exceptional Service:</h4>
<p> At Pizza Shop , we value our customers and strive to provide exceptional service. Our friendly and knowledgeable staff are always ready to assist you in selecting the perfect pizza or answering any questions you may have. We aim to create a welcoming and enjoyable dining experience for all our guests.
</p>
<h4> Community Involvement:</h4>
<p> We believe in giving back to the community that has supported us throughout the years. We actively participate in local events, donate to charitable causes, and support initiatives that promote sustainability and social responsibility.
</p>

<p> We would love to hear from you! If you have any questions, feedback, or suggestions, please don't hesitate to reach out to us using the contact information provided on our "Contact Us" page.

Feel free to modify this example to reflect the unique story and qualities of your pizza shop. You can also include additional information about your team, awards or recognition received, or any other relevant details that you want to highlight.
</p>
            </Row>

        </>
    )
}

export default About
