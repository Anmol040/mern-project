import React from 'react'
import {Container,Row,Col} from 'react-bootstrap'
import NavBar from './Navbar'

const Policy = () => {
  return (
    <>
    <NavBar/>
      <Container style={{marginTop:'50px'}}> </Container>
      <h1> Terms And Policy </h1>
      <Row> 
        <Col md={10}>
        <h6> Lorem, ipsum dolor sit amet consectetur adipisicing elit. Quibusdam, asperiores!</h6>
        <p> Lorem ipsum dolor sit, amet consectetur adipisicing elit. Magnam inventore autem dolor sed? Fugiat, totam laborum nesciunt recusandae consectetur sequi reprehenderit quos illo deleniti mollitia earum! Nihil, libero temporibus itaque ex cumque eum, asperiores nulla saepe exercitationem inventore suscipit ratione odit nam velit aut error deserunt dolores, soluta in? Accusantium blanditiis nisi possimus. Debitis eveniet neque nihil distinctio sint optio fugit aperiam quidem quisquam repudiandae cupiditate unde, reprehenderit doloribus sequi natus placeat, in quibusdam consequatur temporibus aut autem exercitationem. Possimus, magnam maxime eligendi temporibus doloremque illo illum enim, provident non, maiores quis ipsum iure dolorum odio officiis tenetur nostrum dolores!</p>
        <h6> Lorem, ipsum dolor sit amet consectetur adipisicing elit. Quibusdam, asperiores!</h6>
        <p> Lorem ipsum dolor sit, amet consectetur adipisicing elit. Magnam inventore autem dolor sed? Fugiat, totam laborum nesciunt recusandae consectetur sequi reprehenderit quos illo deleniti mollitia earum! Nihil, libero temporibus itaque ex cumque eum, asperiores nulla saepe exercitationem inventore suscipit ratione odit nam velit aut error deserunt dolores, soluta in? Accusantium blanditiis nisi possimus. Debitis eveniet neque nihil distinctio sint optio fugit aperiam quidem quisquam repudiandae cupiditate unde, reprehenderit doloribus sequi natus placeat, in quibusdam consequatur temporibus aut autem exercitationem. Possimus, magnam maxime eligendi temporibus doloremque illo illum enim, provident non, maiores quis ipsum iure dolorum odio officiis tenetur nostrum dolores!</p>
        <h6> Lorem, ipsum dolor sit amet consectetur adipisicing elit. Quibusdam, asperiores!</h6>
        <p> Lorem ipsum dolor sit, amet consectetur adipisicing elit. Magnam inventore autem dolor sed? Fugiat, totam laborum nesciunt recusandae consectetur sequi reprehenderit quos illo deleniti mollitia earum! Nihil, libero temporibus itaque ex cumque eum, asperiores nulla saepe exercitationem inventore suscipit ratione odit nam velit aut error deserunt dolores, soluta in? Accusantium blanditiis nisi possimus. Debitis eveniet neque nihil distinctio sint optio fugit aperiam quidem quisquam repudiandae cupiditate unde, reprehenderit doloribus sequi natus placeat, in quibusdam consequatur temporibus aut autem exercitationem. Possimus, magnam maxime eligendi temporibus doloremque illo illum enim, provident non, maiores quis ipsum iure dolorum odio officiis tenetur nostrum dolores!</p>
        <h6> Lorem, ipsum dolor sit amet consectetur adipisicing elit. Quibusdam, asperiores!</h6>
        <p> Lorem ipsum dolor sit, amet consectetur adipisicing elit. Magnam inventore autem dolor sed? Fugiat, totam laborum nesciunt recusandae consectetur sequi reprehenderit quos illo deleniti mollitia earum! Nihil, libero temporibus itaque ex cumque eum, asperiores nulla saepe exercitationem inventore suscipit ratione odit nam velit aut error deserunt dolores, soluta in? Accusantium blanditiis nisi possimus. Debitis eveniet neque nihil distinctio sint optio fugit aperiam quidem quisquam repudiandae cupiditate unde, reprehenderit doloribus sequi natus placeat, in quibusdam consequatur temporibus aut autem exercitationem. Possimus, magnam maxime eligendi temporibus doloremque illo illum enim, provident non, maiores quis ipsum iure dolorum odio officiis tenetur nostrum dolores!</p>
        <h6> Lorem, ipsum dolor sit amet consectetur adipisicing elit. Quibusdam, asperiores!</h6>
        <p> Lorem ipsum dolor sit, amet consectetur adipisicing elit. Magnam inventore autem dolor sed? Fugiat, totam laborum nesciunt recusandae consectetur sequi reprehenderit quos illo deleniti mollitia earum! Nihil, libero temporibus itaque ex cumque eum, asperiores nulla saepe exercitationem inventore suscipit ratione odit nam velit aut error deserunt dolores, soluta in? Accusantium blanditiis nisi possimus. Debitis eveniet neque nihil distinctio sint optio fugit aperiam quidem quisquam repudiandae cupiditate unde, reprehenderit doloribus sequi natus placeat, in quibusdam consequatur temporibus aut autem exercitationem. Possimus, magnam maxime eligendi temporibus doloremque illo illum enim, provident non, maiores quis ipsum iure dolorum odio officiis tenetur nostrum dolores!</p>
        <h6> Lorem, ipsum dolor sit amet consectetur adipisicing elit. Quibusdam, asperiores!</h6>
        <p> Lorem ipsum dolor sit, amet consectetur adipisicing elit. Magnam inventore autem dolor sed? Fugiat, totam laborum nesciunt recusandae consectetur sequi reprehenderit quos illo deleniti mollitia earum! Nihil, libero temporibus itaque ex cumque eum, asperiores nulla saepe exercitationem inventore suscipit ratione odit nam velit aut error deserunt dolores, soluta in? Accusantium blanditiis nisi possimus. Debitis eveniet neque nihil distinctio sint optio fugit aperiam quidem quisquam repudiandae cupiditate unde, reprehenderit doloribus sequi natus placeat, in quibusdam consequatur temporibus aut autem exercitationem. Possimus, magnam maxime eligendi temporibus doloremque illo illum enim, provident non, maiores quis ipsum iure dolorum odio officiis tenetur nostrum dolores!</p>
        
        
        
        
        </Col>



      </Row>
    </>
  )
}

export default Policy
