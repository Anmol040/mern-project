import React from 'react';
import { Navbar, Nav, Button } from 'react-bootstrap';
import { Link } from 'react-router-dom';

export default function Admin() {
  return (
    <div>
      <Navbar bg="light" expand="lg">
        {/* <Navbar.Brand>Go Food</Navbar.Brand> */}
        <Navbar.Toggle aria-controls="admin-navbar-nav" />
        <Navbar.Collapse id="admin-navbar-nav">
          <Nav className="mr-auto col justify-content-center" >
            <Nav.Link as={Link} to="/addnew-item">
              <Button variant="primary">Add New Item</Button>
            </Nav.Link>
           
            <Nav.Link as={Link} to="/show-item">
              <Button variant="success">Show Items</Button>
            </Nav.Link>
            
          </Nav>
        </Navbar.Collapse>
      </Navbar>
    </div>
  );
}
