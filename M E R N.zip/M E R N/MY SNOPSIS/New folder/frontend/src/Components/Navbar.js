import React, { useState } from 'react'
import './navbar.css'
import { Link } from 'react-router-dom'
import { useDispatch, useSelector } from "react-redux"
import { LogoutUser } from '../actions/userAction'
const NavBar = () => {
    const [change,setChange]=useState(true)
    const dispatch = useDispatch()
    const cartState = useSelector((state) => state.cartReducer);
    // const { currentUser } = useSelector((state) => state.loginUserReducer);
    // const { currentUser } = userState
    // localStorage.getItem('currentUser')
    const { cartItems } = cartState;
    // console.log("fghjk", localStorage.getItem('currentUser'))
    return (
        <>
            <nav className="navbar navbar-expand-lg navbar-light bg-warning">
                <div className="container-fluid">
                    <h1 className="navbar-brand mt-1">PIZZA SHOP</h1>
                    <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                        <span className="navbar-toggler-icon"></span>
                    </button>
                    <div className="collapse navbar-collapse" id="navbarSupportedContent">
                        <ul className="navbar-nav me-auto mb-2 mb-lg-0">
                            <li className="nav-item">
                                <Link className="nav-link active" aria-current="page" to="/">Home</Link>
                            </li>
                            <li className="nav-item">
                                <Link className="nav-link active" aria-current="page" to="/about">About Us</Link>
                            </li>
                            <li className="nav-item">
                                <Link className="nav-link active" aria-current="page" to="/contact">Contact Us</Link>
                            </li>

                        </ul>
                        <form className="d-flex">

                            {!change ?
                             <>
                              {/* <Link to="/login"><button type="button" class="btn btn-primary m-1">Login</button>
                            </Link> */}
                                {/* <Link to="/register"><button type="button" class="btn btn-success m-1">Register</button>
                                </Link> */}
                            </> : <> <Link to="/addnew-item"><button type="button" class="btn btn-success m-1">Admin room</button>
                            </Link>
                                <Link to="/login" onClick={() => {
                                    dispatch(LogoutUser())
                                }}><button type="button" class="btn btn-danger m-1">Logout</button>
                                </Link>
                                <Link to="/cart"><button type="button" class="btn btn-light m-1"> Cart {cartItems.length}</button>
                                </Link>

                                
                                </>}



                            {/* <button className="btn btn-outline-success" type="submit">login</button>
                                <button className="btn btn-outline-success" type="submit">signup</button> */}
                        </form>
                    </div>
                </div>
            </nav>

        </>
    )
}

export default NavBar

// <nav classNameName="navbar navbar-expand-lg bg-dark">
// <div classNameName="container-fluid">
//     <h1 classNameName='text-danger border'>PiZZA SHOP</h1>
//     <div classNameName="collapse navbar-collapse" id="navbarSupportedContent">
//         <ul classNameName="navbar-nav me-auto mb-2 mb-lg-0 center ">

//             < li classNameName="nav-item">
//                 {
//                         currentUser ? (<li classNameName="nav-item">
//                         <Link classNameName="nav-link text-light thumbnail bg-danger m-2 border1" to="/" ><h3>{currentUser.name}</h3></Link>

//                         <NavDropdown title={currentUser.name} id="nav-dropdown">
//                             <NavDropdown.Item eventKey="4.1">oder</NavDropdown.Item>
//                             <NavDropdown.Item onClick={() => {
//                                 dispatch(LogoutUser())
//                             }}>Logout</NavDropdown.Item>

//                             {/* <NavDropdown.Divider /> */}
//                             <NavDropdown.Item eventKey="4.4">Separated link</NavDropdown.Item>
//                         </NavDropdown> </li>
//                     ) : (<><li classNameName="nav-item">
//                         <Link classNameName="nav-link text-light thumbnail bg-danger m-2 border1" to='/register'><h3>Register</h3></Link>

//                         <Link classNameName="nav-link text-light thumbnail bg-danger m-2 border1" to='/login'><h3>Login</h3></Link>
//                     </li></>)
//                 }
//                 <Link classNameName="nav-link active text-light thumbnail" aria-current="page" to="/"><h3>Home</h3></Link>
//             </li>
//             <li classNameName="nav-item" >
//                 <Link classNameName="nav-link text-light thumbnail" to="/about"><h3>About</h3></Link>
//             </li>
//             <li classNameName="nav-item">
//                 <Link classNameName="nav-link text-light thumbnail" to='/contact'><h3>Contact Us</h3></Link>
//             </li>
//         </ul>
//         <form classNameName="d-flex">

//             <li classNameName="nav-item">
//                 <Link classNameName="nav-link text-light thumbnail bg-success m-2 border1" to='/cart'><h3> Cart
//                     {cartItems.length} </h3></Link>
//             </li>
//             {/* <LinkContainer to="/card">card</LinkContainer> */}

//         </form>
//     </div>
// </div>
// </nav>