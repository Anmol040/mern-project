// import logo from './logo.svg';
import './App.css';
import React, { useState } from 'react'


function Signup(props) {

  var [count, setCount] = useState("");
  function store() {
    if ((count["Name"] === "" || count["min"] === "" || count["lastn"] === "") || (Object.keys(count).length < 3)) {
      // alert("All are requid")
      setCount(document.getElementById('first').placeholder = `* name is requied `)
      setCount(document.getElementById('second').placeholder = `* min is requied `)
      setCount(document.getElementById('third').placeholder = `* lastn is requied `)
    }
    if (count["Name"] !== "" && count["min"] !== "" && count["lastn"] !== "" && Object.keys(count).length === 3) {
      console.log("count", count)
    }
  }
  // function add() {
  //   var a = document.getElementById('para')
  //   a.innerHTML += "<input/> <br/>"

  // }

  return (

    <>


      
      <div className="container">
        <fieldset>
          <h1 id='signin'>SIGN IN</h1>
          <input type="text" id="first" placeholder='FirstName' onChange={((e) => {
            setCount({
              ...count,
              Name: e.target.value
            })
          })} />
          <div id="rq1"></div>
          <br />
          <input type="text" id="second" placeholder='MiddleName' onChange={((e) => {
            setCount({
              ...count,
              min: e.target.value
            })

          })} />
          <div id="rq2"></div>

          <br />

          <input type="text" id="third" placeholder='LastName' onChange={((e) => {
            setCount({
              ...count,
              lastn: e.target.value
            })

          })} />
          <div id="rq3"></div>
          <br />
          <input type="button mx=5" id='btnClick' value="submit" onClick={store} />
        </fieldset>
        {/* <fieldset>
          <input type="button" id='btnClick' value="+" onClick={add} />
          <input type="text" id="" />
          <p id="para"></p>
        </fieldset> */}
      </div>
    </>
  );
}

export default Signup;