import React, {useMemo} from "react";
import { useState } from "react";



export default   function Usememo() {
    const [add,setAdd]= useState(1);
    console.log("add",add);

    const [minus, setMinus] = useState(100);
    const x = useMemo(
        function multiply(){
            console.log("first");
            return add * 2;

        },
        [minus]
        

    );
    return (
        <>
       
        {x}
        <h1> {add} </h1>
        <h1> {minus} </h1>

        <button
        onClick={() =>{
            setAdd(add +1);

        }}
        > add</button>

        <button onClick={()=> {
            setMinus(minus -1);
        }}>minus</button>
   
  
        
        </>
    );
}

 