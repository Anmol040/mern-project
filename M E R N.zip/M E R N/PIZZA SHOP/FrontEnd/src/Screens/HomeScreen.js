import React, { useEffect } from 'react'
import { useDispatch, useSelector } from 'react-redux';
import { Container, Row, Col } from 'react-bootstrap';
import { getALLPizzas } from '../actions/pizzaAction'
import Pizza from '../Components/Pizza'
import NavBar from '../Components/Navbar';

const HomeScreen = () => {
  const dispatch = useDispatch();
  const counter = useSelector((state) => state.getALLPizzaReducer)
  const { loading, pizzas, error } = counter;
  // console.log("error", error)
  useEffect(() => {
    dispatch(getALLPizzas());
  }, [dispatch]);
  return (
    <>
      {/* <div id="carouselExampleAutoplaying" className="car carousel slide" data-bs-ride="carousel">
    <div className="carousel-inner">
      <div className="carousel-item active">
        <img src="https://source.unsplash.com/random/300×300/?pizza" className="d-block w-100 h-50" alt="..."/>
      </div>
      <div className="carousel-item">
        <img src="https://source.unsplash.com/random/300×300/?pizza" className="d-block w-100 h-50" alt="..."/>
      </div>
      <div className="carousel-item">
        <img src="https://source.unsplash.com/random/300×300/?pizza" className="d-block w-100 h-50" alt="..."/>
      </div>
    </div>
    <button className="carousel-control-prev" type="button" data-bs-target="#carouselExampleAutoplaying" data-bs-slide="prev">
      <span className="carousel-control-prev-icon" aria-hidden="true"></span>
      <span className="visually-hidden">Previous</span>
    </button>
    <button className="carousel-control-next" type="button" data-bs-target="#carouselExampleAutoplaying" data-bs-slide="next">
      <span className="carousel-control-next-icon" aria-hidden="true"></span>
      <span className="visually-hidden">Next</span>
    </button>
  </div> */}
    <NavBar />
      <Container>
        {
          loading ? (<h1> loading ...</h1>)
            : error ? (<h1> Error while fetching pizzas</h1>)
              : (
                <Row>
                  {pizzas && pizzas.map((pizza) => (
                    <Col md={4}>
                      <Pizza pizza={pizza} />
                    </Col>
                  ))}
                </Row>
              )
        }

      </Container>
    </>
  )
}

export default HomeScreen;
