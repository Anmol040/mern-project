import React, { useState, useEffect } from 'react'
import { useHistory,Link } from "react-router-dom";
import { Container, Form, Button } from 'react-bootstrap'
import { useDispatch, } from 'react-redux'
import { loginUser } from '../actions/userAction'
// import navigator from '@testing-library/jest-dom'

const login = () => {
  const [email, setEmail] = useState('')
  const [password, setPasword] = useState('')
  const dispatch = useDispatch()

  // const navigator = useHistory()
  useEffect(() => {
    if (localStorage.getItem('currentUser')) {
      window.location.href = "/"
      
    }
    
  }, [])
  const loginHandler = () => {
    const user = { email:email, password:password }
    dispatch(loginUser(user))
    
    // navigator.push("/")
  }
  return (
    <>
     <h1 class="text-center mt-4">LOGIN FORM</h1>
      <Container className="border border-5  mt-5 ms-15" >
   
        <Form> 
          <div className="mb-3">
            <label for="exampleInputEmail1" className="form-label">Email address</label>
            <input type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" />
            <div id="emailHelp" className="form-text">We'll never share your email with anyone else.</div>
          </div>
          <div className="mb-3">
            <label for="exampleInputPassword1" className="form-label">Password</label>
            <input type="password"
              value={password}
              onChange={(e) => setPasword(e.target.value)}
              className="form-control" id="exampleInputPassword1" />
          </div>
          <div className="mb-3 form-check">
            <input type="checkbox" className="form-check-input" id="exampleCheck1" />
            <label className="form-check-label" for="exampleCheck1">Check me out</label>
          </div>
          <Button
            onClick={loginHandler}
            className="btn btn-primary">Login</Button>
          <Link to="/register"><button type="button" class="btn btn-success m-1"> I'm not user</button>
          </Link>
        </Form>

      </Container>
    </>
  )
}

export default login
