import React from 'react'
import { Container, Row, Col, Image } from 'react-bootstrap'
import { FcPhone } from 'react-icons/fc'
import { AiOutlineMail } from 'react-icons/ai'
import NavBar from './Navbar'


const Contact = () => {
  return (
    <>
    <NavBar/>
      <Container style={{ marginTop: '50px' }}>
        <Row>
          <Col md={6}>
            <h1> Pizza Shop</h1>
           <p> Contact Us

For any inquiries or to place an order, please reach out to us using the following methods:</p>
            <table className="table">
              <thead>
                <tr>
                  <th className='bg-warning text center' colSpan={3}> --- Contact Details --- </th>

                </tr>
              </thead>
              <tbody>
                <tr>
                  <th >1</th>
                  <td><FcPhone /></td>
                  <td>phone</td>
                  <td>9877331272</td>
                </tr>
                <tr>
                  <th >1</th>
                  <td><FcPhone /></td>
                  <td>call</td>
                  <td>01882</td>
                </tr>
                <tr>
                  <th >1</th>
                  <td><AiOutlineMail /></td>
                  <td>email</td>
                  <td>hspanmol@gmail.com</td>
                </tr>

              </tbody>
            </table>

          </Col>
          <Col md={6}>
            <Image src="https://i.gifer.com/6uCC.gif" style={{ width: "100%", height: "150%" }} />
          </Col>
        </Row>

      </Container>
    </>
  )
}

export default Contact
